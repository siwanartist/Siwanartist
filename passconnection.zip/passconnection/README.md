# 패스커넥션 (PassConnection)

합격자와 취준생을 잇는 커피챗 플랫폼

---

## 🚀 배포 방법 (처음 하는 분도 가능)

### Step 1. MongoDB Atlas 무료 DB 만들기

1. [cloud.mongodb.com](https://cloud.mongodb.com) 접속 → 회원가입
2. **Build a Database** → **M0 Free** 선택 → **Create**
3. Username / Password 설정 (기억해두기)
4. **Network Access** → **Add IP Address** → **Allow Access from Anywhere**
5. **Connect** → **Drivers** → Connection String 복사
   - 예: `mongodb+srv://myuser:mypass@cluster0.xxxxx.mongodb.net/passconnection`

---

### Step 2. Render.com 서버 배포

1. [render.com](https://render.com) 접속 → GitHub으로 회원가입
2. **New** → **Web Service**
3. GitHub 저장소 연결
4. 설정:
   - **Name**: `passconnection`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free
5. **Environment Variables** 탭에서 아래 값 입력:

```
MONGODB_URI    = (Step 1에서 복사한 주소)
JWT_SECRET     = (아무 랜덤 문자열 64자)
SESSION_SECRET = (아무 랜덤 문자열 32자)
BASE_URL       = https://passconnection.onrender.com
NODE_ENV       = production
TOSS_CLIENT_KEY = test_ck_placeholder
TOSS_SECRET_KEY = test_sk_placeholder
```

6. **Create Web Service** → 3~5분 후 배포 완료!

---

### Step 3. 소셜 로그인 설정 (선택, 나중에 해도 됨)

#### Google OAuth
1. [console.cloud.google.com](https://console.cloud.google.com) 접속
2. 새 프로젝트 → **API 및 서비스** → **OAuth 2.0 클라이언트 ID** 생성
3. 승인된 리디렉션 URI: `https://passconnection.onrender.com/api/auth/google/callback`
4. Client ID, Secret을 Render 환경변수에 추가:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`

#### 네이버 OAuth
1. [developers.naver.com](https://developers.naver.com) → 애플리케이션 등록
2. 서비스 URL: `https://passconnection.onrender.com`
3. 콜백 URL: `https://passconnection.onrender.com/api/auth/naver/callback`
4. Client ID, Secret을 Render 환경변수에 추가:
   - `NAVER_CLIENT_ID`
   - `NAVER_CLIENT_SECRET`

---

### Step 4. SMS 인증 설정 (선택)

**NHN Cloud** (사업자 없이 개인도 가능)
1. [console.nhncloud.com](https://console.nhncloud.com) 회원가입
2. **Notification > SMS** 서비스 활성화
3. 앱키/시크릿키 발급
4. 발신번호 등록 (본인 전화번호)
5. 환경변수 추가:
   - `NHN_APP_KEY`
   - `NHN_SECRET_KEY`
   - `NHN_SENDER_PHONE`

> ⚠️ SMS 미설정 시 개발 모드로 동작 (코드가 서버 콘솔에 출력됨)

---

### Step 5. 실제 결제 설정 (사업자 등록 후)

1. [developers.tosspayments.com](https://developers.tosspayments.com) 가입
2. 테스트 키 발급 → 실제 키는 사업자 등록 후 발급
3. 현재는 샌드박스 모드로 동작 (실제 돈 안 나감)

---

## 📁 프로젝트 구조

```
passconnection/
├── server/
│   ├── index.js          # 서버 진입점
│   ├── config/
│   │   └── passport.js   # Google/네이버 OAuth
│   ├── models/
│   │   ├── User.js       # 유저 스키마
│   │   ├── Payment.js    # 결제 기록
│   │   └── SmsCode.js    # SMS 인증 코드
│   ├── middleware/
│   │   └── auth.js       # JWT 인증 미들웨어
│   └── routes/
│       ├── auth.js       # 회원가입/로그인/OAuth
│       ├── user.js       # 프로필/아바타
│       ├── mentor.js     # 멘토 목록/등록
│       ├── payment.js    # 결제/토큰
│       └── sms.js        # SMS 인증
├── public/
│   ├── index.html        # 프론트엔드 (전체 UI)
│   └── uploads/          # 업로드된 이미지
├── .env.example          # 환경변수 예시
├── .gitignore
└── package.json
```

---

## 🔑 API 엔드포인트

| 메서드 | 경로 | 설명 |
|--------|------|------|
| POST | `/api/auth/register` | 이메일 회원가입 |
| POST | `/api/auth/login` | 이메일 로그인 |
| GET | `/api/auth/me` | 내 정보 |
| GET | `/api/auth/google` | Google 로그인 |
| GET | `/api/auth/naver` | 네이버 로그인 |
| GET | `/api/auth/check-nickname/:n` | 닉네임 중복 확인 |
| POST | `/api/sms/send` | SMS 인증문자 발송 |
| POST | `/api/sms/verify` | SMS 인증번호 확인 |
| GET | `/api/user/profile` | 내 프로필 |
| PATCH | `/api/user/profile` | 프로필 수정 |
| POST | `/api/user/avatar` | 프로필 사진 업로드 |
| GET | `/api/mentor` | 멘토 목록 |
| POST | `/api/payment/prepare` | 주문 생성 |
| POST | `/api/payment/confirm` | 결제 승인 |
| POST | `/api/payment/use-coin` | 토큰 사용 (예약) |
